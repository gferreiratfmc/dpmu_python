## Installations
1.  Install Pyhon
    https://www.python.org/
2.  Install "Kvaser CANlib SDK" from https://www.kvaser.com/download/?utm_source=software&utm_ean=7330130980150&utm_status=latest
3. On Windows install "Kvaser Drivers for Windows" from https://www.kvaser.com/download/?utm_source=software&utm_ean=7330130980013&utm_status=latest

## Start Virtual Environment
4.	Start a terminal client (e.g. PowerShell)
5.	Go to the folder that contains folder ‘.DPMU_CAN’
7.	Run ‘.DPMU_CAN\Scripts\activate’
    (Now the Virtual environment is started)
    
## Run the script
7.	Run ‘complex_example.py’
